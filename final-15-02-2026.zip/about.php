<?php include 'header.php' ?>
<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/breadcumb-bg.jpg" data-overlay="title" data-opacity="8">
    <div class="breadcumb-shape" data-bg-src="assets/img/bg/breadcumb_shape_1_1.png"></div>
    <div class="shape-mockup breadcumb-shape2 jump d-lg-block d-none" data-right="30px" data-bottom="30px"><img
            src="assets/img/bg/breadcumb_shape_1_2.png" alt="shape"></div>
    <div class="shape-mockup breadcumb-shape3 jump-reverse d-lg-block d-none" data-left="50px" data-bottom="80px">
        <img src="assets/img/bg/breadcumb_shape_1_3.png" alt="shape">
    </div>
    <div class="container">
        <div class="breadcumb-content text-center">
            <h1 class="breadcumb-title">about</h1>
            <ul class="breadcumb-menu">
                <li><a href="index.php">Home</a></li>
                <li>  About</li>
            </ul>
        </div>
    </div>
</div>




<!-- ----------About STEM Section----------- -->
<section class="space">
    <div class="container z-index-common">
        <div class="row d-flex justify-content-center align-item-center">
            <div class="col-10">
                <div class="title-area mb-30">

                    <h2 class="sec-title fw-medium">
                        About STEM
                    </h2>
                </div>
                <p class="mb-15">
                    Science, Technology, Engineering, and Mathematics (STEM) collectively represent the
                    foundation of innovation, economic development, and sustainable societal progress. STEM
                    disciplines drive advancements in areas such as artificial intelligence, healthcare, renewable
                    energy, smart infrastructure, and digital transformation.
                </p>
                <p class="mb-15">
                    In the global knowledge economy, STEM education equips learners with essential
                    competencies including analytical thinking, problem-solving, computational skills, creativity,
                    and technological literacy. These skills are critical for addressing complex global challenges
                    and for building resilient, future-ready societies.
                </p>
                <p class="mb-15">
                    STEM also plays a crucial role in workforce development by aligning education with
                    industry needs and emerging technologies. By integrating academic learning with real-world
                    applications, STEM education supports employability, entrepreneurship, and lifelong
                    learning.
                </p>
                <p class="mb-15">
                    Promoting inclusive STEM education is essential to ensure that innovation benefits from
                    diverse perspectives and that no group is excluded from opportunities created by
                    technological progress.
                </p>


            </div>

        </div>
    </div>
    </div>

</section>



<section class="space bg-smoke" id="about-sec">
    <div class="container">

        <!-- Section Heading -->
        <div class="row justify-content-center mb-5">
            <div class="col-xl-10 ">
                <div class="title-area mb-30">
                    <h2 class="sec-title fw-medium">
                        Challenges and Hurdles Faced by Women in STEM
                    </h2>
                </div>
                <p class="mb-15">
                    Despite global efforts to promote gender equality, women remain significantly
                    underrepresented in many STEM fields, particularly in advanced technology and leadership
                    roles. This gap is influenced by interconnected social, educational, and institutional
                    challenges.
                </p>
            </div>
        </div>

        <!-- Content Row -->
        <div class="row align-items-start">

            <div class="col-xl-10 mx-auto">

                <h3 class="sub-title fw-semibold mb-4">
                    Key Challenges
                </h3>

                <div class="challenge-card mb-3">
                    <h4>Gender Stereotypes and Social Norms</h4>
                    <p>
                        Persistent perceptions that STEM careers are male-dominated discourage girls and women
                        from pursuing STEM education and professions.
                    </p>
                </div>

                <div class="challenge-card mb-3">
                    <h4>Limited Access to Role Models and Mentors</h4>
                    <p>
                        The lack of visible women leaders in STEM reduces confidence, aspiration, and career
                        guidance for young women.
                    </p>
                </div>

                <div class="challenge-card mb-3">
                    <h4>Educational and Digital Skill Gaps</h4>
                    <p>
                        Unequal access to quality STEM education, advanced digital tools, and AI training
                        limits participation and progression.
                    </p>
                </div>

                <div class="challenge-card mb-3">
                    <h4>Workplace Barriers</h4>
                    <p>
                        Gender bias, pay inequality, limited leadership opportunities, and lack of inclusive
                        workplace cultures affect retention and career growth.
                    </p>
                </div>

                <div class="challenge-card mb-4">
                    <h4>Balancing Professional and Personal Responsibilities</h4>
                    <p>
                        Inadequate institutional support for caregiving and flexible working conditions
                        can restrict long-term engagement in STEM careers.
                    </p>
                </div>

                <p class="text-center fw-medium mt-4">
                    Addressing these challenges requires targeted interventions, inclusive policies,
                    mentorship programs, industry engagement, and skill-focused initiatives that empower
                    women to succeed and lead in STEM fields.
                </p>

            </div>


        </div>
    </div>
</section>






<section class="space bg-white" id="about-sec">
    <div class="container">

        <!-- Section Heading -->
        <div class="row justify-content-center">
            <div class="col-xl-10 ">
                <div class="title-area mb-30">
                    <h2 class="sec-title fw-medium">
                        Introduction to the British Council (BC)
                    </h2>
                </div>
                <p class="mb-15">
                    The British Council is the United Kingdom’s international organization for cultural relations and educational opportunities. It works globally to build trust, mutual understanding, and lasting connections between the UK and partner countries through education, arts, culture, and the English language.
                </p>
                <p class="mb-15">
                    In higher education and research, the British Council supports international collaboration, academic mobility, skills development, and institutional capacity building. It plays a key role in strengthening global partnerships that promote inclusion, innovation, and social impact.
                </p>
                <p>
                    Through its education and research programs, the British Council actively promotes gender equality, digital transformation, and equitable access to learning opportunities, ensuring that underrepresented groups can participate fully in global knowledge systems.
                </p>
            </div>
        </div>
    </div>
</section>


<section class="space bg-smoke" id="global-partnerships">
    <div class="container">

        <!-- Section Heading -->
        <div class="row justify-content-center">
            <div class="col-xl-10 ">
                <div class="title-area mb-30">
                    <h2 class="sec-title fw-medium">
                        Introduction to the Going Global Partnerships Scheme
                    </h2>
                </div>
                <p class="mb-15">
                    The <strong>Going Global Partnerships (GGP) </strong>scheme is a flagship initiative of the British Council designed to support sustainable international collaboration in education, research, and skills development.
                </p>
                <p class="mb-15">
                    The scheme focuses on building long-term partnerships between higher education institutions and industry across countries, enabling co-creation of innovative solutions to shared global challenges.
                </p>

            </div>
        </div>


        <div class="row align-items-start">

            <div class="col-xl-10 mx-auto">

                <!-- Feature Grid -->
                <div class="row g-4">

                    <!-- Feature 1 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card h-100">
                            <div class="icon-box">
                                <i class="fa-solid fa-globe"></i>
                            </div>
                            <h4>Transnational Education & Industry Collaboration</h4>
                            <p>
                                Strengthening cross-border education initiatives and fostering
                                industry–academia collaboration to address global skill demands.
                            </p>
                        </div>
                    </div>

                    <!-- Feature 2 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card h-100">
                            <div class="icon-box">

                                <i class="fa-solid fa-laptop-code"></i>
                            </div>
                            <h4>Inclusive Access to Education & Digital Skills</h4>
                            <p>
                                Promoting equitable access to quality education and digital skill
                                development for underrepresented and marginalized groups.
                            </p>
                        </div>
                    </div>

                    <!-- Feature 3 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card h-100">
                            <div class="icon-box">
                                <i class="fa-solid fa-venus-mars"></i>
                            </div>
                            <h4>Gender Equality & Social Inclusion</h4>
                            <p>
                                Supporting initiatives that advance gender equality, diversity,
                                and inclusive participation across education and employment sectors.
                            </p>
                        </div>
                    </div>

                    <!-- Feature 4 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card h-100">
                            <div class="icon-box">

                                <i class="fa-solid fa-briefcase"></i>
                            </div>
                            <h4>Employability & Workforce Readiness</h4>
                            <p>
                                Enhancing employability by aligning education outcomes with
                                industry needs and future workforce requirements.
                            </p>
                        </div>
                    </div>

                    <!-- Feature 5 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card h-100">
                            <div class="icon-box">
                                <i class="fa-solid fa-lightbulb"></i>
                            </div>
                            <h4>Innovation & Applied Research</h4>
                            <p>
                                Encouraging collaborative innovation and applied research that
                                addresses real-world challenges and supports economic growth.
                            </p>
                        </div>
                    </div>

                </div>


                <p class="mt-20">
                    The scheme focuses on building long-term partnerships between higher education institutions and industry across countries, enabling co-creation of innovative solutions to shared global challenges.
                </p>
            </div>
        </div>
    </div>
</section>



<?php include 'footer.php' ?>