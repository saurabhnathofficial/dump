<?php include 'header.php' ?>

<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/breadcumb-bg.jpg" data-overlay="title" data-opacity="8">
    <div class="breadcumb-shape" data-bg-src="assets/img/bg/breadcumb_shape_1_1.png"></div>
    <div class="shape-mockup breadcumb-shape2 jump d-lg-block d-none" data-right="30px" data-bottom="30px"><img
            src="assets/img/bg/breadcumb_shape_1_2.png" alt="shape"></div>
    <div class="shape-mockup breadcumb-shape3 jump-reverse d-lg-block d-none" data-left="50px" data-bottom="80px">
        <img src="assets/img/bg/breadcumb_shape_1_3.png" alt="shape">
    </div>
    <div class="container">
        <div class="breadcumb-content text-center">
            <h1 class="breadcumb-title">Updates</h1>
            <ul class="breadcumb-menu">
                <li><a href="index.php">Home</a></li>
                <li>Updates</li>
            </ul>
        </div>
    </div>
</div>



<section class="space-top space-extra-bottom">
    <div class="container">
        <div class="row">
            <div class="col-xl-10 col-xxl-10 col-lg-10 mx-auto">
                <div class="row">
                    <div class="col-xxl-8 col-lg-8">
                        <div class="event-details-wrap" id="update-1">
                            <div class="event-img"><img style="min-width: 100%;" src="assets/img/updates/update-1.png" alt="Event Image"></div>
                            <h3 class="h3 mt-n2">British Council</h3>
                            <p class="mb-20">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, architecto? Nobis similique delectus quod nostrum! Distinctio minus, fuga eveniet libero modi voluptatem soluta iusto quod inventore sint quidem iure aperiam expedita odio dicta a omnis vel, vitae delectus repellendus dignissimos ullam labore. Suscipit a itaque sapiente, ut quisquam placeat ratione!</p>
                            <p class="mb-0">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id, nostrum, iure reiciendis corporis assumenda maxime in repellendus error quos ducimus natus sit dicta culpa tenetur magni magnam tempore veritatis a?
                            </p>
                        </div>
                        <div class="event-details-wrap" id="update-2">
                            <div class="event-img"><img style="min-width: 100%;" src="assets/img/updates/update-2.png" alt="Event Image"></div>
                            <h3 class="h3 mt-n2">Going Global Partnerships</h3>
                            <p class="mb-20">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, architecto? Nobis similique delectus quod nostrum! Distinctio minus, fuga eveniet libero modi voluptatem soluta iusto quod inventore sint quidem iure aperiam expedita odio dicta a omnis vel, vitae delectus repellendus dignissimos ullam labore. Suscipit a itaque sapiente, ut quisquam placeat ratione!</p>
                            <p class="mb-0">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id, nostrum, iure reiciendis corporis assumenda maxime in repellendus error quos ducimus natus sit dicta culpa tenetur magni magnam tempore veritatis a?
                            </p>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-lg-4">
                        <aside class="sidebar-area">
                            <div class="widget widget_info">
                                <h3 class="widget_title">Updates</h3>
                                <div class="info-list">
                                    <ul>
                                        <li>
                                            <a href="#update-1">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <strong>Update : 1</strong>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#update-2">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <strong>Update : 2</strong>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <strong>Update : 3</strong>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <strong>Update : 4</strong>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="">
                                                <i class="fa-solid fa-arrow-right"></i>
                                                <strong>Update : 5</strong>
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                            </div>




                            <div class="widget">
                                <h3 class="widget_title">Recent Update</h3>
                                <div class="recent-post-wrap">
                                    <div class="recent-post">
                                        <div class="media-img"><a href=""><img
                                                    src="assets/img/blog/recent-post-1-1.jpg" alt=""></a></div>
                                        <div class="media-body">
                                            <h4 class="post-title"><a class="text-inherit" href="#update-1">Introduction to the British Council (BC)</a></h4>
                                            <div class="recent-post-meta"><a href="#update-1"><i
                                                        class="fas fa-calendar"></i>21/6/2025</a></div>
                                        </div>
                                    </div>
                                    <div class="recent-post">
                                        <div class="media-img"><a href=""><img
                                                    src="assets/img/blog/recent-post-1-2.jpg" alt=""></a></div>
                                        <div class="media-body">
                                            <h4 class="post-title"><a class="text-inherit" href="#update-2">Introduction to the Going Global Partnerships</a></h4>
                                            <div class="recent-post-meta"><a href="#update-2"><i
                                                        class="fas fa-calendar"></i>2/12/2025</a></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php' ?>