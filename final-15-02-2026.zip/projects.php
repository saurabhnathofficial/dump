<?php include 'header.php' ?>


<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/breadcumb-bg.jpg" data-overlay="title" data-opacity="8">
  <div class="breadcumb-shape" data-bg-src="assets/img/bg/breadcumb_shape_1_1.png"></div>
  <div class="shape-mockup breadcumb-shape2 jump d-lg-block d-none" data-right="30px" data-bottom="30px"><img
      src="assets/img/bg/breadcumb_shape_1_2.png" alt="shape"></div>
  <div class="shape-mockup breadcumb-shape3 jump-reverse d-lg-block d-none" data-left="50px" data-bottom="80px">
    <img src="assets/img/bg/breadcumb_shape_1_3.png" alt="shape">
  </div>
  <div class="container">
    <div class="breadcumb-content text-center">
      <h1 class="breadcumb-title">About Project</h1>
      <ul class="breadcumb-menu">
        <li><a href="index.php">Home</a></li>
        <li>Projects</li>
      </ul>
    </div>
  </div>
</div>

<section class="space">
  <div class="container">
    <div class="">

      <div class="row">
        <div class="col-xl-10 mx-auto">
          <div class="col-auto">
            <div class="about-info">
              <h2 class="title text-center">Empowering Women in STEM with Applied AI and
                Digital Skills Development</h2>
            </div>
          </div>
        </div>
      </div>




      <div class="why-area-1 mt-2 overflow-hidden">

        <div class="container">
          <div class="row align-items-center">
            <div class="col-xl-10 mx-auto">
              <div class="wcu-wrap1">
                <div class="title-area  ">
                  <p class="h6"><span class="sub-title mb-0 mt-4">Funding Scheme:</span>
                    Going Global Partnerships – Industry Academia TNE Grants 2025–26 (British Council)</p>
                  <p class="h6"><span class="sub-title mb-0 mt-2">Grant Value:</span>
                    €20,000</p>
                  <p>This project is supported under the British Council’s Going Global Partnerships initiative,
                    aiming to strengthen international collaboration between academia and industry while
                    addressing global skills gaps.</p>
                  <!-- <h2 class="sec-title ">Project Aim & Objectives</h2> -->
                  <h3 class="h5 mb-0"> Project Aim:</h3>
                  <p class=" ">The project WINS-AID (Women IN STEM – AI and Digital Skills) aims to empower women in
                    STEM by enhancing digital and AI skills through targeted training, mentorship, and industry
                    collaboration. It seeks to reduce gender disparities, improve employability, and foster innovation,
                    thereby creating a sustainable pipeline of skilled women professionals who can contribute effectively
                    to the evolving digital economy.</p>
                </div>
                <div class="row gy-4">
                  <h3 class="h5 mt-0 mb-0">Key Objectives:</h3>
                  <div class="col-auto">
                    <div class="wcu-box">

                      <div class="wcu-box_details w-100">

                        <ul class="fs-5">
                          <li class="mb-10">Train at least 100 women in STEM with advanced digital and AI competencies through
                            structured workshops and certification programs.</li>
                          <li class="mb-10">Develop and deliver a jointly created hybrid curriculum integrating academic and industry-led
                            digital and AI modules.</li>
                          <li class="mb-10">Facilitate a mentorship program pairing women participants with STEM faculty and industry
                            professionals to support skill development and career guidance.</li>
                          <li class="mb-10">Organize industry-linked practical experiences such as hackathons, coding sprints, and short-
                            term internships to enhance employability.</li>
                          <li class="mb-10">Establish mechanisms to monitor and evaluate participant skill acquisition, job placements,
                            and long-term career progression for sustainability.</li>
                          <li class="mb-10">Develop institutional strategies and policy recommendations for promoting gender equity in
                            digital education.</li>
                        </ul>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="bg-smoke py-5" id="team">
  <div class="container">


    <!-- Section Heading -->
    <div class="row justify-content-center mb-5">
      <div class="col-xl-10 ">
        <div class="title-area mb-30">
          <h2 class="sec-title fw-medium">
            Key Team Members
          </h2>
        </div>
      </div>
    </div>
    <div class="row justify-content-center mb-5">
      <div class="col-xl-10 ">
        <!-- ================= University of Aberdeen ================= -->
        <div class="institution-title mb-4">
          <h4>University of Aberdeen, Scotland, UK</h4>
        </div>

        <div class="row mb-5">
          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Dr. S. M. Riazul Islam</h5>
                <p class="fw-semibold mb-1">Project Lead / Lead Project Coordinator</p>
                <p class="mb-1">Associate Professor (Senior Lecturer) of Computing Science</p>
                <p class="text-muted mb-0">University of Aberdeen</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Dr. Yining Hua</h5>
                <p class="fw-semibold mb-1">Lecturer</p>
                <p class="mb-1">School of Natural and Computing Sciences</p>
                <p class="text-muted mb-0">University of Aberdeen</p>
              </div>
            </div>
          </div>
        </div>

        <!-- ================= VIT ================= -->
        <div class="institution-title mb-4">
          <h4>Vellore Institute of Technology (VIT), India</h4>
        </div>

        <div class="row mb-5">
          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Prof. Ramalingam</h5>
                <p class="mb-1">School of Computer Science Engineering and Information Systems</p>
                <p class="text-muted mb-0">VIT, Vellore, Tamil Nadu, India</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Prof. Dharmendra Singh Rajput</h5>
                <p class="mb-1">School of Computer Science Engineering and Information Systems</p>
                <p class="text-muted mb-0">VIT, Vellore, Tamil Nadu, India</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Prof. Kuruva Lakshmana</h5>
                <p class="mb-1">School of Computer Science Engineering and Information Systems</p>
                <p class="text-muted mb-0">VIT, Vellore, Tamil Nadu, India</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Prof. Rajeswari</h5>
                <p class="mb-1">School of Computer Science Engineering and Information Systems</p>
                <p class="text-muted mb-0">VIT, Vellore, Tamil Nadu, India</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Prof. Harshitha Patel</h5>
                <p class="mb-1">School of Computer Science Engineering and Information Systems</p>
                <p class="text-muted mb-0">VIT, Vellore, Tamil Nadu, India</p>
              </div>
            </div>
          </div>
        </div>

        <!-- ================= Technogaze ================= -->
        <div class="institution-title mb-4">
          <h4>Technogaze Solutions Private Limited, India</h4>
        </div>

        <div class="row">
          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Mr. Devendra Gaur</h5>
                <p class="text-muted mb-0">Technogaze Solutions Private Limited</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 mb-4">
            <div class="team-card h-100">
              <div class="card-body">
                <h5 class="card-title">Mr. Sivam Singh</h5>
                <p class="text-muted mb-0">Technogaze Solutions Private Limited</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="bg-smoke pb-4" id="team">
  <div class="container">


    <!-- Section Heading -->
    <div class="row justify-content-center mb-5">
      <div class="col-xl-10 ">
        <div class="row">

          <div class="col-auto order-xl-1">
            <div class="title-area mb-30">
              <h2 class="sec-title fw-medium text-center">Key Focus Areas</h2>
            </div>
            <div class="row gy-2">
              <div class="col-sm-6">
                <div class="become-instructor-wrap p-2">
                  <i class="fa-solid fa-badge-check"></i>
                  <h4 class="h6 mb-0 mx-auto">Applied Artificial Intelligence</h4>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="become-instructor-wrap p-2"><i class="fa-solid fa-badge-check"></i>
                  <h4 class="h6 mb-0 mx-auto">Digital Skills Development</h4>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="become-instructor-wrap p-2"><i class="fa-solid fa-badge-check"></i>
                  <h4 class="h6 mb-0 mx-auto">Industry-oriented Training Modules</h4>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="become-instructor-wrap p-2"><i class="fa-solid fa-badge-check"></i>
                  <h4 class="h6 mb-0 mx-auto">AI for Real-World Problem Solving</h4>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="become-instructor-wrap p-2"><i class="fa-solid fa-badge-check"></i>
                  <h4 class="h6 mb-0 mx-auto">Workforce Readiness & Employability</h4>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="become-instructor-wrap p-2"><i class="fa-solid fa-badge-check"></i>
                  <h4 class="h6 mb-0 mx-auto">Women Leadership in Technology</h4>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>

  </div>
</section>





<?php include 'footer.php' ?>