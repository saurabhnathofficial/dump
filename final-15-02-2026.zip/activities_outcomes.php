<?php include 'header.php' ?>


<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/breadcumb-bg.jpg" data-overlay="title" data-opacity="8">
    <div class="breadcumb-shape" data-bg-src="assets/img/bg/breadcumb_shape_1_1.png"></div>
    <div class="shape-mockup breadcumb-shape2 jump d-lg-block d-none" data-right="30px" data-bottom="30px"><img
            src="assets/img/bg/breadcumb_shape_1_2.png" alt="shape"></div>
    <div class="shape-mockup breadcumb-shape3 jump-reverse d-lg-block d-none" data-left="50px" data-bottom="80px">
        <img src="assets/img/bg/breadcumb_shape_1_3.png" alt="shape">
    </div>
    <div class="container">
        <div class="breadcumb-content text-center">
            <h1 class="breadcumb-title">Activities & Outcomes</h1>
            <ul class="breadcumb-menu">
                <li><a href="index.php">Home</a></li>
                <li>Activities & Outcomes</li>
            </ul>
        </div>
    </div>
</div>



<section class="bg-smoke py-5" id="proposed-activities">
    <div class="container">
        <div class="row">
            <div class="col-10 mx-auto">

                <div class="title-area mb-30 text-center">
                    <h2 class="sec-title fw-medium">
                        Proposed Activities
                    </h2>
               
                </div>

            

                <!-- Activities -->
                <div class="row g-4 mb-5">

                    <div class="col-lg-6">
                        <div class="activity-card h-100">
                            <span class="activity-step">Activity 1</span>
                            <h4>Insight Discovery & Stakeholder Consultation</h4>
                            <p>
                                Conduct comprehensive surveys, focus groups, and interviews with women
                                in STEM, academic faculty, industry partners, and other stakeholders to
                                gather qualitative and quantitative data on current digital and AI skill
                                levels, barriers to participation, and training needs.
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="activity-card h-100">
                            <span class="activity-step">Activity 2</span>
                            <h4>Strategic Curriculum Innovation & Design</h4>
                            <p>
                                Analyze data from the needs assessment to identify digital and AI skill
                                gaps and opportunities. Collaborate with academic and industry partners
                                to co-design an innovative, hybrid curriculum integrating cutting-edge
                                digital and AI competencies. Develop course modules, training toolkits,
                                and digital resources for pilot workshops.
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="activity-card h-100">
                            <span class="activity-step">Activity 3</span>
                            <h4>Empowerment Through Digital & AI Skill Building</h4>
                            <p>
                                Implement hybrid workshops and online training sessions focused on
                                foundational to advanced digital and AI competencies for women in STEM.
                                Delivered by academic and industry experts, sessions combine interactive
                                learning, coding sprints, and problem-solving labs.
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="activity-card h-100">
                            <span class="activity-step">Activity 4</span>
                            <h4>Impact Synthesis and Policy Advocacy</h4>
                            <p>
                                Conduct a comprehensive evaluation of project outcomes focused on women’s
                                digital and AI skill enhancement in STEM. Analyze monitoring data and
                                stakeholder feedback to synthesise effectiveness, challenges, lessons
                                learned, and develop policy recommendations advocating gender-inclusive
                                AI and STEM education frameworks.
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="activity-card h-100">
                            <span class="activity-step">Activity 5</span>
                            <h4>Transnational Consortium Meeting – Consolidation and Integration</h4>
                            <p>
                                A mid-project transnational meeting will unite all partners to review
                                insights, curriculum innovations, digital and AI skill-building outcomes,
                                and preliminary impact. It will enable shared reflection, lesson
                                integration, progress alignment, and co-creation of next steps, including
                                policy advocacy strategies, held virtually or in person.
                            </p>
                        </div>
                    </div>

                </div>

                <!-- Outcomes -->
                <div class="text-center mb-4">
                    <h2 class="fw-bold">Expected Outcomes</h2>
                </div>

                <div class="outcomes-box">

                    <ul class="outcome-list">
                        <li>
                            Baseline report completed incorporating skill gap analysis and stakeholder
                            insights from the UK and India. Identifies competencies, participation
                            barriers, employer expectations, and provides evidence for curriculum
                            development, industry alignment, and evaluation parameters.
                        </li>

                        <li>
                            Co-developed hybrid curriculum and digital resource toolkit including
                            applied AI and digital skills modules, industry-informed case studies, and
                            embedded practical activities such as hackathons, coding sprints, and
                            short-term internships. Participant portfolios and employer feedback will
                            evidence enhanced employability.
                        </li>

                        <li>
                            Hybrid workshops delivered to pilot the curriculum with women in STEM,
                            complemented by a structured mentorship programme pairing participants
                            with STEM faculty and industry professionals. Certification awarded with
                            feedback demonstrating measurable gains in skills, confidence, career
                            guidance, and networking capacity.
                        </li>

                        <li>
                            Comprehensive evaluation report produced summarising pilot results,
                            participant outcomes, mentorship impact, and lessons learned. Includes
                            policy suggestions for gender equity frameworks in STEM education.
                            Findings disseminated through a joint UK–India seminar and targeted
                            advocacy.
                        </li>

                        <li>
                            Joint reflection resulting in a consolidated learning document, scaling
                            action plan, and alignment on collaborative next steps. Enables sustained
                            impact through continued curriculum use, extended industry engagement,
                            and replication across other transnational education contexts.
                        </li>
                    </ul>

                </div>

            </div>
        </div>
    </div>
</section>





<?php include 'footer.php' ?>