<?php include 'includes/header.php' ?>

<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/breadcumb-bg.jpg" data-overlay="title" data-opacity="8">
    <div class="breadcumb-shape" data-bg-src="assets/img/bg/breadcumb_shape_1_1.png"></div>
    <div class="shape-mockup breadcumb-shape2 jump d-lg-block d-none" data-right="30px" data-bottom="30px"><img
            src="assets/img/bg/breadcumb_shape_1_2.png" alt="shape"></div>
    <div class="shape-mockup breadcumb-shape3 jump-reverse d-lg-block d-none" data-left="50px" data-bottom="80px">
        <img src="assets/img/bg/breadcumb_shape_1_3.png" alt="shape">
    </div>
    <div class="container">
        <div class="breadcumb-content text-center">
            <h1 class="breadcumb-title">Partner</h1>
            <ul class="breadcumb-menu">
                <li><a href="index.php">Home</a></li>
                <li>Partners</li>
            </ul>
        </div>
    </div>
</div>



<section class="space">
    <div class="container">
        <div class="row">
            <div class="col-xxl-10 mx-auto">
                <div class="title-area text-center">
                    <h2 class="sec-title">Project Partners</h2>
                    <p class="px-3">This project is delivered through a collaborative partnership between academic and industry institutions from the United Kingdom and India. Each partner contributes complementary expertise to support skills development, inclusion, and international collaboration in STEM.</p>
                </div>
                <div class="row gy-4 justify-content-center">
                    <div class="col-xl-4 col-md-6">
                        <div class="price-card">
                            <div class="price-card_top">
                                <h3 class="h6 text-start">UK Academic Partner</h3>
                                <h4 class="text-start">University of Aberdeen (UK)</h4>
                            </div>
                            <div class="text-start">
                               <p>A globally recognised research-intensive university with strong expertise in data science, artificial intelligence, and interdisciplinary STEM education.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="price-card">
                            <div class="price-card_top">
                                <h3 class="h6 text-start">Indian Academic Partner</h3>
                                <h4 class="text-start">Vellore Institute of Technology (India)</h4>
                            </div>
                            <div class="text-start">
                               <p>One of India’s leading higher education institutions, known for excellence in engineering, technology, innovation, and global academic collaborations.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="price-card">
                            <div class="price-card_top">
                                <h3 class="h6 text-start">Industry Partner</h3>
                                <h4 class="text-start">Technogaze Solutions Pvt. Ltd.</h4>
                            </div>
                            <div class="text-start">
                               <p>An industry partner providing applied AI use cases, real-world insights, and mentorship to ensure alignment with current and future workforce needs.</p>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php' ?>