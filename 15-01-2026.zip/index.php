<?php include 'includes/header.php'; ?>

<!-- ----------Hero Section----------- -->
<div class="th-hero-wrapper hero-6" id="hero">
    <div class="hero-slider-6 th-carousel" id="heroSlide6" >
        <div class="th-hero-slide ">
            <div class="th-hero-bg" data-bg-src="assets/img/bg/hero_bg.jpg">
                <img src="assets/img/bg/hero_overlay.png" alt="Hero Image" />
            </div>
            <div class="container">
                <div class="hero-style6">

                    <h1 class="hero-title" data-ani="slideindown" data-ani-delay="0.4s">
                        Empowering Women <br> in STEM with Applied AI and Digital Skills Development
                    </h1>
                    <div class="checklist" data-ani="slideinup" data-ani-delay="0.1s">
                        <p class="hero-text mb-2">This project is supported under the British Council’s Going Global Partnerships initiative,
                            aiming to strengthen international collaboration between academia and industry while <br>
                            addressing global skills gaps.</p>

                        <p class=" hero-text"><span class="title fw-semibold m-0">Project Duration:</span> 17 October 2025 – 16 October 2026</p>
                    </div>
                    <div class="btn-group" data-ani="slideinup" data-ani-delay="0.5s">
                        <a href="projects.php" class="th-btn style6">Learn More<i
                                class="fas fa-long-arrow-right ms-2"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- ----------About STEM Section----------- -->
<section class="space">
    <div class="container z-index-common">
        <div class="row d-flex justify-content-center align-item-center">

            <div class="col-xl-8">
                <div class="title-area mb-30">
                    <span class="sub-title">About</span>
                    <h2 class="sec-title fw-medium">
                        About STEM
                    </h2>
                </div>
                <p class="mb-20">
                    Science, Technology, Engineering, and Mathematics (STEM) collectively represent the
                    foundation of innovation, economic development, and sustainable societal progress. STEM
                    disciplines drive advancements in areas such as artificial intelligence, healthcare, renewable
                    energy, smart infrastructure, and digital transformation.
                </p>
                <p class="mb-20">
                    In the global knowledge economy, STEM education equips learners with essential
                    competencies including analytical thinking, problem-solving, computational skills, creativity,
                    and technological literacy. These skills are critical for addressing complex global challenges
                    and for building resilient, future-ready societies.
                </p>
                <p class="mb-20">
                    STEM also plays a crucial role in workforce development by aligning education with
                    industry needs and emerging technologies. By integrating academic learning with real-world
                    applications, STEM education supports employability, entrepreneurship, and lifelong
                    learning.
                </p>
                <p class="mb-20">
                    Promoting inclusive STEM education is essential to ensure that innovation benefits from
                    diverse perspectives and that no group is excluded from opportunities created by
                    technological progress.
                </p>

                <a href="STEM_women.php" class="th-btn">Learn More<i class="fas fa-arrow-right ms-2"></i></a>
            </div>

            <div class="col-xl-4 mt-4 mb-xl-0">
                <div class="img-box7 tilt-active">
                    <img class="w-100" src="assets/img/normal/about_v2_3_1.jpg" alt="About" />
                </div>
            </div>

        </div>
    </div>

</section>



<div class="counter-area-2" data-bg-src="assets/img/bg/counter-bg_1.png">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-sm-6 col-xl-3 counter-card-wrap">
                <div class="counter-card">
                    <h2 class="counter-card_number">
                        <span >1</span>
                    </h2>
                    <p class="counter-card_text">
                        <strong>Year Duration</strong>
                    </p>
                </div>
            </div>

            <!-- Women in STEM -->
            <div class="col-sm-6 col-xl-3 counter-card-wrap">
                <div class="counter-card">
                    <h2 class="counter-card_number">
                        <span >100</span>
                        <span class="fw-normal">+</span>
                    </h2>
                    <p class="counter-card_text">
                        <strong>Women in STEM</strong> Trained
                    </p>
                </div>
            </div>

            <!-- Countries -->
            <div class="col-sm-6 col-xl-3 counter-card-wrap">
                <div class="counter-card">
                    <h2 class="counter-card_number">
                        <span>2</span>
                    </h2>
                    <p class="counter-card_text">
                        <strong>Countries</strong> Involved
                    </p>
                </div>
            </div>

            <!-- Partners -->
            <div class="col-sm-6 col-xl-3 counter-card-wrap">
                <div class="counter-card">
                    <h2 class="counter-card_number">
                        <span>3</span>
                    </h2>
                    <p class="counter-card_text">
                        <strong>Project</strong> Partners
                    </p>
                </div>
            </div>

        </div>
    </div>
</div>


<!-- ----------Project Aim & Objective Section----------- -->

<!-- <div class="why-area-1 space overflow-hidden">
    <div class="shape-mockup why-shape-1 jump" data-top="10%" data-left="7%"><img
            src="assets/img/normal/about_1_shape1.png" alt="img"></div>
    <div class="shape-mockup why-shape-2" data-bg-src="assets/img/normal/wcu_1_shape1.png"></div>
    <div class="shape-mockup why-shape-3 jump-reverse" data-bottom="25%" data-right="-3%"><img
            src="assets/img/normal/wcu_1_shape2.png" alt="img"></div>
    <div class="container">
        <div class="row align-items-center">
            
            <div class="col-xl-6">
                <div class="wcu-wrap1">
                    <div class="title-area mb-25"><span class="sub-title"></i>Aim & Obj</span>
                        <h2 class="sec-title">Project Aim & Objectives</h2>
                        <h3 class="h5 mt-20 mb-0"> Project Aim:</h3>
                        <p class="sec-text ">The project WINS-AID (Women IN STEM – AI and Digital Skills) aims to empower women in STEM by enhancing digital and AI skills through targeted training, mentorship, and industry collaboration.</p>
                    </div>
                    <div class="row gy-4">
                        <h3 class="h5 mt-35 mb-0">Key Objectives:</h3>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">

                                    <p class="wcu-box_text">Enhance digital and AI skills among women</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">

                                    <p class="wcu-box_text">Strengthen academia–industry collaboration
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">

                                    <p class="wcu-box_text">Promote gender inclusion in STEM
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">
                                    <p class="wcu-box_text">Support global skills development
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="wcu-img-1">
                    <div class="img1"><img src="assets/img/normal/wcu_1_1.png" alt="img"></div>

                    <div class="text-end"><a class="th-btn mt-30" href="projects.php">learn more <i
                                class="far fa-arrow-right ms-1"></i></a></div>
                </div>
            </div>
        </div>
    </div>
</div> -->


<!-- ----------Partner Section----------- -->
<section class="space " id="course-sec">
    <div class="container">
        <div class="title-area text-center"><span class="sub-title">Partnership</span>
            <h2 class="sec-title fw-medium">Our Project Partners</h2>
        </div>
        <div class="row py-3">
            <div class="col-sm-6 col-xl-4">
                <div class="category-card2 ">
                    <div class="category-card2_icon"><img src="assets/img/icons/category_1_1.svg" alt="icon">
                    </div>
                    <div class="category-card2_content">
                        <h3 class="category-card2_title"><a href="partners.php">UK Academic Partner</a></h3>
                        <p class="category-card2_text">University of Aberdeen</p><a href="partners.php" class="link-btn">Learn More<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="category-card2">
                    <div class="category-card2_icon"><img src="assets/img/icons/category_1_2.svg" alt="icon">
                    </div>
                    <div class="category-card2_content">
                        <h3 class="category-card2_title"><a href="partners.php">Indian Academic Partner</a></h3>
                        <p class="category-card2_text">Vellore Institute of Technology (VIT)</p><a href="partners.php" class="link-btn">Learn More<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="category-card2">
                    <div class="category-card2_icon"><img src="assets/img/icons/category_1_3.svg" alt="icon">
                    </div>
                    <div class="category-card2_content">
                        <h3 class="category-card2_title"><a href="partners.php">Industry Partner</a></h3>
                        <p class="category-card2_text">Technogaze Solutions Private Limited</p><a href="partners.php" class="link-btn">Learn More<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<!-- --------------update section----------- -->

<section class="space bg-smoke">
    <div class="container">
        <div class="title-area text-center">
            <span class="sub-title">Latest News & updates</span>
            <h2 class="sec-title fw-medium">Get Every Single Updates</h2>
        </div>
        <div class="row slider-shadow th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2"
            data-sm-slide-show="1">
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_1.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 15, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Marketing</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Designing Better Link Web Site and Emailsite Valued</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_2.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 16, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Technology</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Morishing Better Link Web Site and Emailsite galowo</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_3.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 17, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Programing</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Kariabnim Better Link Web Site and Emailsite Tanial</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_4.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 18, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Technology</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Gusakanis Better Link Web Site and Emailsite Monasi</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="shape-mockup d-none d-md-block" data-top="0%" data-left="0%">
        <img src="assets/img/shape/shadow_1.png" alt="shapes" />
    </div>
</section>






<?php include 'includes/footer.php'; ?>