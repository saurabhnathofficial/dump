<?php include 'includes/header.php' ?>
<style>

</style>


<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/breadcumb-bg.jpg" data-overlay="title" data-opacity="8">
    <div class="breadcumb-shape" data-bg-src="assets/img/bg/breadcumb_shape_1_1.png"></div>
    <div class="shape-mockup breadcumb-shape2 jump d-lg-block d-none" data-right="30px" data-bottom="30px"><img
            src="assets/img/bg/breadcumb_shape_1_2.png" alt="shape"></div>
    <div class="shape-mockup breadcumb-shape3 jump-reverse d-lg-block d-none" data-left="50px" data-bottom="80px">
        <img src="assets/img/bg/breadcumb_shape_1_3.png" alt="shape">
    </div>
    <div class="container">
        <div class="breadcumb-content text-center">
            <h1 class="breadcumb-title">STEM & Women</h1>
            <ul class="breadcumb-menu">
                <li><a href="index.php">Home</a></li>
                <li>Women in STEM</li>
            </ul>
        </div>
    </div>
</div>


<div class="space" id="about-sec">
    <div class="container">

        <div class="row justify-content-around">
            <div class="col-xxl-10">
                <div class="row">

                    <div class="col-xl-9 mx-auto">
                        <div class="title-area mb-35">
                            <h2 class="sec-title fw-semibold ">Challenges and Hurdles Faced by Women in STEM</h2>
                        </div>
                        <p class="mt-n2 mb-35    ">Despite global efforts to promote gender equality, women remain significantly
                            underrepresented in many STEM fields, particularly in advanced technology and leadership
                            roles. This gap is influenced by interconnected social, educational, and institutional
                            challenges.</p>
                        <!-- <a href="about.html" class="th-btn">Learn More<i class="fas fa-arrow-right ms-2"></i></a> -->
                    </div>
                    <div class="col-xl-3">
                        <div class="img-box10">
                            <div style="max-height: 240px;" class="mb-2 img1 tilt-active"><img src="assets/img/normal/about_v2_5_1.jpg" alt="about">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <h2 class="sub-title fw-semibold">Key challenges include:</h2>


                    <div class="bg-smoke p-4 rounded-2 my-2">
                        <h4 class="fs-5  mb-1">Gender Stereotypes and Social Norms: </h4>
                        <p class="mt-0">Persistent perceptions that STEM careers
                            are male-dominated discourage girls and women from pursuing STEM education and
                            professions.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-2">
                        <h4 class="fs-5  mb-1">Limited Access to Role Models and Mentors: </h4>
                        <p class="mt-0">The lack of visible women leaders in
                            STEM reduces confidence, aspiration, and career guidance for young women.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-2">
                        <h4 class="fs-5  mb-1">Educational and Digital Skill Gaps: </h4>
                        <p class="mt-0">Unequal access to quality STEM education,
                            advanced digital tools, and AI training limits participation and progression.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-2">
                        <h4 class="fs-5  mb-1">Workplace Barriers: </h4>
                        <p class="mt-0">Gender bias, pay inequality, limited leadership opportunities,
                            and lack of inclusive workplace cultures affect retention and career growth.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-2">
                        <h4 class="fs-5  mb-1">Balancing Professional and Personal Responsibilities: </h4>
                        <p class="mt-0">Inadequate institutional
                            support for caregiving and flexible working conditions can restrict long-term
                            engagement in STEM careers.</p>
                    </div>
                    <p class="mt-4 text-center">Addressing these challenges requires targeted interventions, inclusive policies, mentorship
                        programs, industry engagement, and skill-focused initiatives that empower women to succeed
                        and lead in STEM fields.</p>


                </div>
            </div>
        </div>
    </div>
</div>








<!-- <section class="mt-5 space-extra-bottom">
    <div class="container">
        <div class="row">
            <div class="mx-auto col-xxl-9 col-lg-8">
                <div class="event-details-wrap">
                    <h3 class="h3 mt-n2 text-center">Challenges and Hurdles Faced by Women in STEM</h3>
                    <div class=" event-img "><img src="assets/img/project/project1.jpg" alt="Event Image" style="width: 100% !important;"></div>

                    <p class="mb-30 sub-text ">Despite global efforts to promote gender equality, women remain significantly
                        underrepresented in many STEM fields, particularly in advanced technology and leadership
                        roles. This gap is influenced by interconnected social, educational, and institutional
                        challenges.</p>

                    <h4 class="fs-3 mt-5 text-center">Key challenges include:</h4>
                    <div class="bg-smoke p-4 rounded-2 my-4">
                        <h4 class="fs-5  mb-1">Gender Stereotypes and Social Norms: </h4>
                        <p class="mt-0">Persistent perceptions that STEM careers
                            are male-dominated discourage girls and women from pursuing STEM education and
                            professions.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-4">
                        <h4 class="fs-5  mb-1">Limited Access to Role Models and Mentors: </h4>
                        <p class="mt-0">The lack of visible women leaders in
                            STEM reduces confidence, aspiration, and career guidance for young women.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-4">
                        <h4 class="fs-5  mb-1">Educational and Digital Skill Gaps: </h4>
                        <p class="mt-0">Unequal access to quality STEM education,
                            advanced digital tools, and AI training limits participation and progression.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-4">
                        <h4 class="fs-5  mb-1">Workplace Barriers: </h4>
                        <p class="mt-0">Gender bias, pay inequality, limited leadership opportunities,
                            and lack of inclusive workplace cultures affect retention and career growth.</p>
                    </div>
                    <div class="bg-smoke p-4 rounded-2 my-4">
                        <h4 class="fs-5  mb-1">Balancing Professional and Personal Responsibilities: </h4>
                        <p class="mt-0">Inadequate institutional
                            support for caregiving and flexible working conditions can restrict long-term
                            engagement in STEM careers.</p>
                    </div>
                    <p class="mt-4 text-center">Addressing these challenges requires targeted interventions, inclusive policies, mentorship
                        programs, industry engagement, and skill-focused initiatives that empower women to succeed
                        and lead in STEM fields.</p>











                </div>
            </div>
        </div>
    </div>
</section> -->





<?php include 'includes/footer.php' ?>