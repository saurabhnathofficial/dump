
<?php include 'includes/header.php' ?>

   <style>
        .activity-card {
            border-left: 4px solid #0d6efd;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .activity-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        .activity-number {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #0d6efd, #0a58ca);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
        .outcome-item {
            border-left: 3px solid #198754;
            padding-left: 1rem;
            margin-bottom: 1.5rem;
        }
        .section-title {
            position: relative;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #0d6efd, #0a58ca);
        }



</style>
<section class="py-5 bg-light">
        <div class="container">
            <!-- Proposed Activities -->
            <div class="mb-5">
                <h2 class="section-title fw-bold">Proposed Activities</h2>
                
                <!-- Activity 1 -->
                <div class="card activity-card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <div class="activity-number me-3">1</div>
                            <h4 class="fw-bold mt-2">Insight Discovery & Stakeholder Consultation</h4>
                        </div>
                        <p class="text-muted">
                            Conduct comprehensive surveys, focus groups, and interviews with women in STEM, academic faculty, industry partners, and other stakeholders to gather qualitative and quantitative data on current digital and AI skill levels, barriers to participation, and training needs.
                        </p>
                    </div>
                </div>

                <!-- Activity 2 -->
                <div class="card activity-card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <div class="activity-number me-3">2</div>
                            <h4 class="fw-bold mt-2">Strategic Curriculum Innovation & Design</h4>
                        </div>
                        <p class="text-muted">
                            Analyze data from the needs assessment to identify digital and AI skill gaps and opportunities. Collaborate with academic and industry partners to co-design an innovative, hybrid curriculum that integrates cutting-edge digital and AI competencies. Develop course modules, training toolkits, and digital resources to be piloted in workshops.
                        </p>
                    </div>
                </div>

                <!-- Activity 3 -->
                <div class="card activity-card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <div class="activity-number me-3">3</div>
                            <h4 class="fw-bold mt-2">Empowerment Through Digital & AI Skill Building</h4>
                        </div>
                        <p class="text-muted">
                            Implement hybrid workshops and online training sessions focused on building foundational to advanced digital and AI competencies for women in STEM. Delivered by expert trainers from both academia and industry, the sessions combine interactive learning, coding sprints, and problem-solving labs.
                        </p>
                    </div>
                </div>

                <!-- Activity 4 -->
                <div class="card activity-card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <div class="activity-number me-3">4</div>
                            <h4 class="fw-bold mt-2">Impact Synthesis and Policy Advocacy</h4>
                        </div>
                        <p class="text-muted">
                            Conduct a comprehensive evaluation of project outcomes focused on women's digital and AI skill enhancement in STEM. Analyze monitoring data and stakeholder feedback to synthesize findings on effectiveness, challenges, and lessons learned. Develop policy recommendations advocating for gender-inclusive AI and STEM education frameworks.
                        </p>
                    </div>
                </div>

                <!-- Activity 5 -->
                <div class="card activity-card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <div class="activity-number me-3">5</div>
                            <h4 class="fw-bold mt-2">Transnational Consortium Meeting – Consolidation and Integration</h4>
                        </div>
                        <p class="text-muted">
                            A mid-project transnational meeting will unite all partners to review insights, curriculum innovations, digital and AI skill-building outcomes, and preliminary impact. It will enable shared reflection, lesson integration, progress alignment, and co-creation of next steps, including policy advocacy strategies, held virtually or in person.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Outcomes Section -->
            <div class="mt-5">
                <h2 class="section-title fw-bold">Outcomes</h2>
                
                <div class="outcome-item">
                    <p>
                        <strong>Baseline report completed,</strong> incorporating skill gap analysis and stakeholder insights from UK and India. This will identify current competencies, barriers to participation, and employer expectations, providing an evidence base for curriculum development, industry alignment, and evaluation parameters for the pilot programme.
                    </p>
                </div>

                <div class="outcome-item">
                    <p>
                        <strong>Co-developed hybrid curriculum and digital resource toolkit,</strong> including applied AI and digital skills modules, industry-informed case studies, and embedded practical activities such as hackathons, coding sprints, and short-term internships. Participant portfolios and employer feedback will evidence enhanced employability.
                    </p>
                </div>

                <div class="outcome-item">
                    <p>
                        <strong>Workshops delivered in hybrid format</strong> to pilot the curriculum with women in STEM, complemented by a structured mentorship programme pairing participants with STEM faculty and industry professionals. Participants receive certification, with feedback showing measurable gains in skills, confidence, career guidance, and networking capacity.
                    </p>
                </div>

                <div class="outcome-item">
                    <p>
                        <strong>Comprehensive evaluation report produced,</strong> summarising pilot results, participant outcomes, mentorship impact, and lessons learned. Includes policy suggestions for gender equity frameworks in STEM education. Findings disseminated via a joint UK–India seminar and targeted advocacy to relevant education and industry bodies.
                    </p>
                </div>

                <div class="outcome-item">
                    <p>
                        <strong>Joint reflection between partners</strong> resulting in a consolidated learning document, action plan for scaling the model, and alignment on collaborative next steps. This will enable sustained impact through continued curriculum use, extended industry engagement, and replication in other TNE contexts.
                    </p>
                </div>
            </div>
        </div>
    </section>


    <?php include 'includes/footer.php' ?>
