<!-- ---------FOOTER START---------- -->
<footer class="footer-wrapper footer-layout6">
    <div class="widget-area">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-md-6 col-xxl-3 col-xl-4">
                    <div class="widget footer-widget">
                        <div class="th-widget-about">
                            <div class="about-logo">
                                <a href="index.html"><img class="w-25" src="assets/img/logo/logo.png"
                                        alt="Edura" /></a>
                            </div>
                            <p class="about-text">
                                Empowering Women in STEM with Applied AI and Digital Skills Development
                            </p>
                            <div class="th-social">
                                <h6 class="title text-white">FOLLOW US ON:</h6>
                                <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-auto">
                    <div class="widget widget_nav_menu footer-widget style2">
                        <h3 class="widget_title">Quick Links</h3>
                        <div class="menu-all-pages-container">
                            <ul class="menu">

                                <li>
                                    <a href="index.php">Home</a>
                                </li>

                                <li>
                                    <a href="STEM_women.php">STEM & Women</a>
                                </li>

                                <li>
                                    <a href="projects.php">Projects</a>
                                </li>

                                <li>
                                    <a href="partners.php">Partners</a>
                                </li>

                                <li>
                                    <a href="activities_outcomes.php">Activities & Outcomes</a>
                                </li>

                                <li>
                                    <a href="funding.php">Funding</a>

                                </li>
                

                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-xl-auto">
                    <div class="widget widget_nav_menu footer-widget style2">
                        <h3 class="widget_title">Project Partners</h3>
                        <div class="menu-all-pages-container">
                            <ul class="menu">
                                <li><a href="">University of Aberdeen, United Kingdom</a></li>
                                <li><a href="">Vellore Institute of Technology (VIT), India</a></li>
                                <li><a href="">Technogaze Solutions Private Limited, India</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="widget newsletter-widget footer-widget style2">
                        <h3 class="widget_title">Funding Acknowledgement</h3>
                        <p class="footer-text">
                            This project is funded under the British Council’s Going Global Partnerships – Industry
                            Academia TNE Grants 2025–26, which supports international collaboration, inclusion, and
                            global skills development.
                        </p>
                        <button type="submit" class="th-btn style3">
                            Contact Now <i class="far fa-arrow-right ms-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-wrap">
        <div class="container">
            <div class="row justify-content-between align-items-center">

                <p class="copyright-text text-center">
                    &copy; 2026 TechnoGaze. All Rights Reserved
                </p>

            </div>
        </div>
    </div>

    <!-- <div class="shape-mockup jump d-none d-xl-block" data-top="10%" data-left="0%">
        <img src="../assets/img/shape/footer_shape_4.png" alt="shapes" />
    </div>
    <div class="shape-mockup movingX d-none d-xl-block" data-bottom="15%" data-right="0%">
        <img src="../assets/img/shape/footer_shape_5.png" alt="shapes" />
    </div> -->
</footer>



<!-- ----------SCRIPT----------  -->
<script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="assets/js/app.min.js"></script>
<script src="assets/js/main.js"></script>
</body>

</html>