<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>
        STEM
    </title>
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no" />
    <link rel="shortcut icon" href="assets/img/favicon/favicon.ico" type="image/x-icon" />
    <!-- ----------GOOGLE FONTS----------  -->
    <link rel="preconnect" href="https://fonts.googleapis.com/" />
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&amp;family=Jost:wght@300;400;500;600;700;800;900&amp;family=Roboto:wght@100;300;400;500;700&amp;display=swap"
        rel="stylesheet" />

    <!-- ----------EXTERNAL CSS----------  -->
    <link rel="stylesheet" href="assets/css/app.min.css" />
    <link rel="stylesheet" href="assets/css/fontawesome.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
</head>

<body>

    <!-- ----------Mobile Menu----------  -->
    <div class="th-menu-wrapper">
        <div class="th-menu-area text-center">
            <button class="th-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo">
                <a href="index.html"><img src="assets/img/logo/logo.png" alt="LOGO" /></a>
            </div>

            <div class="th-mobile-menu">
                <ul>
                    <li>
                        <a href="index.php">Home</a>
                    </li>

                    <li>
                        <a href="STEM_women.php">STEM & Women</a>
                    </li>

                    <li>
                        <a href="projects.php">Projects</a>
                    </li>

                    <li>
                        <a href="updates.php">Updates</a>
                    </li>
                    <li>
                        <a href="partners.php">Partners</a>
                    </li>

                    <li>
                        <a href="activities_outcomes.php">Activities & Outcomes</a>
                    </li>

                </ul>
            </div>
        </div>
    </div>

    <!-- ----------Main Nav----------  -->
    <header class="th-header header-layout6">

        <div class="sticky-wrapper">
            <div class="sticky-active">
                <div class="menu-area" data-bg-src="assets/img/update1/bg/pattern_bg_2.png">
                    <div class="container">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-auto">
                                <div class="header-logo">
                                    <a href="index.html"><img src="assets/img/logo/logo.png" alt="logo" /></a>
                                </div>
                            </div>
                            <div class="col-auto ">
                                <div class="row align-items-center">
                                    <div class="col-auto d-flex align-items-center justify-content-center">
                                        <nav class="main-menu d-none d-lg-inline-block">
                                            <ul>
                                                <li>
                                                    <a href="index.php">Home</a>
                                                </li>

                                                <li>
                                                    <a href="STEM_women.php">STEM & Women</a>
                                                </li>

                                                <li>
                                                    <a href="projects.php">Projects</a>
                                                </li>

                                                <li>
                                                    <a href="updates.php">Updates</a>
                                                </li>
                                                <li>
                                                    <a href="partners.php">Partners</a>
                                                </li>

                                                <li>
                                                    <a href="activities_outcomes.php">Activities & Outcomes</a>
                                                </li>

                                            </ul>

                                        </nav>

                                        <button type="button" class="th-menu-toggle d-inline-block d-lg-none">
                                            <i class="far fa-bars"></i>
                                        </button>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="logo-shape"></div>
                </div>
            </div>
        </div>
    </header>