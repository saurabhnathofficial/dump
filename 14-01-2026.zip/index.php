<?php include 'includes/header.php'; ?>

<!-- ----------Hero Section----------- -->
<div class="th-hero-wrapper hero-6" id="hero">
    <div class="hero-slider-6 th-carousel" id="heroSlide6" data-slide-show="1" data-md-slide-show="1"
        data-fade="true">
        <div class="th-hero-slide">
            <div class="th-hero-bg" data-bg-src="assets/img/bg/hero_bg.jpg">
                <img src="assets/img/bg/hero_overlay.png" alt="Hero Image" />
            </div>
            <div class="container">
                <div class="hero-style6">

                    <h1 class="hero-title" data-ani="slideindown" data-ani-delay="0.4s">
                        Empowering Women <br> in STEM with Applied AI and Digital Skills Development
                    </h1>
                    <div class="checklist" data-ani="slideinup" data-ani-delay="0.1s">
                        <p class="hero-text mb-2">This project is supported under the British Council’s Going Global Partnerships initiative,
                            aiming to strengthen international collaboration between academia and industry while <br>
                            addressing global skills gaps.</p>

                        <p class=" hero-text"><span class="title fw-semibold m-0">Project Duration:</span> 17 October 2025 – 16 October 2026</p>
                    </div>
                    <div class="btn-group" data-ani="slideinup" data-ani-delay="0.5s">
                        <a href="projects.php" class="th-btn style6">Learn More<i
                                class="fas fa-long-arrow-right ms-2"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="th-hero-slide">
                <div class="th-hero-bg" data-bg-src="assets/img/update1/hero/hero_bg_6_2.jpg">
                    <img src="assets/img/update1/hero/hero_overlay_6.png" alt="Hero Image" />
                </div>
                <div class="container">
                    <div class="hero-style6">
                        <span class="hero-subtitle" data-ani="slideindown" data-ani-delay="0.7s">Edura is the best place
                            for any online courses.</span>
                        <h1 class="hero-title" data-ani="slideindown" data-ani-delay="0.4s">
                            Get the quality course
                        </h1>
                        <h1 class="hero-title" data-ani="slideindown" data-ani-delay="0.1s">
                            for your future.
                        </h1>
                        <div class="checklist" data-ani="slideinup" data-ani-delay="0.1s">
                            <ul>
                                <li>Experts Advisors</li>
                                <li>538+ Courses</li>
                            </ul>
                        </div>
                        <div class="btn-group" data-ani="slideinup" data-ani-delay="0.5s">
                            <a href="about.html" class="th-btn style3">Get Started<i
                                    class="fas fa-long-arrow-right ms-2"></i></a>
                            <a href="course.html" class="th-btn style6">Our Courses<i
                                    class="fas fa-long-arrow-right ms-2"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-bg-src="assets/img/update1/hero/hero_bg_6_3.jpg">
                    <img src="assets/img/update1/hero/hero_overlay_6.png" alt="Hero Image" />
                </div>
                <div class="container">
                    <div class="hero-style6">
                        <span class="hero-subtitle" data-ani="slideindown" data-ani-delay="0.7s">Start learning with
                            Edura for better future.</span>
                        <h1 class="hero-title" data-ani="slideindown" data-ani-delay="0.4s">
                            We collect the best
                        </h1>
                        <h1 class="hero-title" data-ani="slideindown" data-ani-delay="0.1s">
                            IT course for you.
                        </h1>
                        <div class="checklist" data-ani="slideinup" data-ani-delay="0.1s">
                            <ul>
                                <li>Experts Advisors</li>
                                <li>538+ Courses</li>
                            </ul>
                        </div>
                        <div class="btn-group" data-ani="slideinup" data-ani-delay="0.5s">
                            <a href="about.html" class="th-btn style3">Get Started<i
                                    class="fas fa-long-arrow-right ms-2"></i></a>
                            <a href="course.html" class="th-btn style6">Our Courses<i
                                    class="fas fa-long-arrow-right ms-2"></i></a>
                        </div>
                    </div>
                </div>
            </div> -->
    </div>
    <!-- <div class="icon-box">
        <button data-slick-prev="#heroSlide6" class="slick-arrow default">
            <i class="far fa-chevron-left"></i>
        </button>
        <button data-slick-next="#heroSlide6" class="slick-arrow default">
            <i class="far fa-chevron-right"></i>
        </button>
    </div> -->
</div>


<!-- ----------About STEM Section----------- -->
<section class="space">
    <div class="container z-index-common">
        <div class="row d-flex justify-content-center align-item-center">

            <div class="col-xl-8">
                <div class="title-area mb-30">
                    <span class="sub-title">About</span>
                    <h2 class="sec-title fw-medium">
                        About STEM
                    </h2>
                </div>
                <p class="mb-20">
                    Science, Technology, Engineering, and Mathematics (STEM) collectively represent the
                    foundation of innovation, economic development, and sustainable societal progress. STEM
                    disciplines drive advancements in areas such as artificial intelligence, healthcare, renewable
                    energy, smart infrastructure, and digital transformation.
                </p>
                <p class="mb-20">
                    In the global knowledge economy, STEM education equips learners with essential
                    competencies including analytical thinking, problem-solving, computational skills, creativity,
                    and technological literacy. These skills are critical for addressing complex global challenges
                    and for building resilient, future-ready societies.
                </p>
                <p class="mb-20">
                    STEM also plays a crucial role in workforce development by aligning education with
                    industry needs and emerging technologies. By integrating academic learning with real-world
                    applications, STEM education supports employability, entrepreneurship, and lifelong
                    learning.
                </p>
                <p class="mb-20">
                    Promoting inclusive STEM education is essential to ensure that innovation benefits from
                    diverse perspectives and that no group is excluded from opportunities created by
                    technological progress.
                </p>

                <a href="STEM_women.php" class="th-btn">Learn More<i class="fas fa-arrow-right ms-2"></i></a>
            </div>

            <div class="col-xl-4 mt-4 mb-xl-0">
                <div class="img-box7 tilt-active">
                    <img class="w-100" src="assets/img/normal/about_v2_3_1.jpg" alt="About" />
                </div>
            </div>

        </div>
    </div>

</section>








<!-- ----------Project Aim & Objective Section----------- -->

<div class="why-area-1 space overflow-hidden">
    <div class="shape-mockup why-shape-1 jump" data-top="10%" data-left="7%"><img
            src="assets/img/normal/about_1_shape1.png" alt="img"></div>
    <div class="shape-mockup why-shape-2" data-bg-src="assets/img/normal/wcu_1_shape1.png"></div>
    <div class="shape-mockup why-shape-3 jump-reverse" data-bottom="25%" data-right="-3%"><img
            src="assets/img/normal/wcu_1_shape2.png" alt="img"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-6">
                <div class="wcu-img-1">
                    <div class="img1"><img src="assets/img/normal/wcu_1_1.png" alt="img"></div>

                    <div class="text-end"><a class="th-btn mt-30" href="projects.php">learn more <i
                                class="far fa-arrow-right ms-1"></i></a></div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="wcu-wrap1">
                    <div class="title-area mb-25"><span class="sub-title"></i>Aim & Obj</span>
                        <h2 class="sec-title">Project Aim & Objectives</h2>
                        <h3 class="h5 mt-20 mb-0"> Project Aim:</h3>
                        <p class="sec-text ">The project WINS-AID (Women IN STEM – AI and Digital Skills) aims to empower women in STEM by enhancing digital and AI skills through targeted training, mentorship, and industry collaboration.</p>
                    </div>
                    <div class="row gy-4">
                        <h3 class="h5 mt-35 mb-0">Key Objectives:</h3>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">

                                    <p class="wcu-box_text">Enhance digital and AI skills among women</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">

                                    <p class="wcu-box_text">Strengthen academia–industry collaboration
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">

                                    <p class="wcu-box_text">Promote gender inclusion in STEM
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wcu-box">
                                <div class="wcu-box_icon"><i class="fas fa-check-circle"></i></div>
                                <div class="wcu-box_details">
                                    <p class="wcu-box_text">Support global skills development
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>






<!-- ----------Partner Section----------- -->
<section class="space " id="course-sec">
    <div class="container">
        <div class="title-area text-center"><span class="sub-title">Partnership</span>
            <h2 class="sec-title fw-medium">Our Project Partners</h2>
        </div>
        <div class="row py-3">
            <div class="col-sm-6 col-xl-4">
                <div class="category-card2 ">
                    <div class="category-card2_icon"><img src="assets/img/icons/category_1_1.svg" alt="icon">
                    </div>
                    <div class="category-card2_content">
                        <h3 class="category-card2_title"><a href="partners.php">UK Academic Partner</a></h3>
                        <p class="category-card2_text">University of Aberdeen</p><a href="partners.php" class="link-btn">Learn More<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="category-card2">
                    <div class="category-card2_icon"><img src="assets/img/icons/category_1_2.svg" alt="icon">
                    </div>
                    <div class="category-card2_content">
                        <h3 class="category-card2_title"><a href="partners.php">Indian Academic Partner</a></h3>
                        <p class="category-card2_text">Vellore Institute of Technology (VIT)</p><a href="partners.php" class="link-btn">Learn More<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="category-card2">
                    <div class="category-card2_icon"><img src="assets/img/icons/category_1_3.svg" alt="icon">
                    </div>
                    <div class="category-card2_content">
                        <h3 class="category-card2_title"><a href="partners.php">Industry Partner</a></h3>
                        <p class="category-card2_text">Technogaze Solutions Private Limited</p><a href="partners.php" class="link-btn">Learn More<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- 
<div class="why-sec-v2 overflow-hidden space" data-bg-src="assets/img/bg/why-bg-2.png">
    <div class="shape-mockup why2-shape-1 spin" data-top="40%" data-right="6%"><img
            src="assets/img/normal/wcu_2_shape1.png" alt="img"></div>
    <div class="shape-mockup why2-shape-2 jump" data-bottom="25%" data-left="3%"><img
            src="assets/img/normal/blog-3-bg-shape.png" alt="img"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-6 align-self-end order-xl-2">
                <div class="wcu-img-2 mb-50 mb-xl-0"><img src="assets/img/normal/wcu_2_1.png" alt="img"></div>
            </div>
            <div class="col-xl-6 order-xl-1">
                <div class="wcu-wrap2">
                    <div class="title-area mb-xl-5"><span class="sub-title"><i class="fal fa-book me-1"></i> WHY
                            CHOOSE US</span>
                        <h2 class="sec-title">Transform Education Your Life, Change the World</h2>
                    </div>
                    <div class="row g-4">
                        <div class="col-sm-6">
                            <div class="wcu-box style2">
                                <div class="wcu-box_icon"><img src="assets/img/icon/wcu-icon-2-1.svg" alt="img">
                                </div>
                                <div class="wcu-box_details">
                                    <h3 class="h5 wcu-box_title"><a href="service-details.html">Expert
                                            Instruction</a></h3>
                                    <p class="wcu-box_text">We offer a wide range of educational products and
                                        services.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="wcu-box style2">
                                <div class="wcu-box_icon"><img src="assets/img/icon/wcu-icon-2-2.svg" alt="img">
                                </div>
                                <div class="wcu-box_details">
                                    <h3 class="h5 wcu-box_title"><a href="service-details.html">Find Video
                                            Courses</a></h3>
                                    <p class="wcu-box_text">Online education offers a wide range of courses &
                                        programs, covering.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="wcu-box style2">
                                <div class="wcu-box_icon"><img src="assets/img/icon/wcu-icon-2-3.svg" alt="img">
                                </div>
                                <div class="wcu-box_details">
                                    <h3 class="h5 wcu-box_title"><a href="service-details.html">Online Courses</a>
                                    </h3>
                                    <p class="wcu-box_text">Innovative market without extensive coordinate stand
                                        alone catalysts for.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="wcu-box style2">
                                <div class="wcu-box_icon"><img src="assets/img/icon/wcu-icon-2-4.svg" alt="img">
                                </div>
                                <div class="wcu-box_details">
                                    <h3 class="h5 wcu-box_title"><a href="service-details.html">Learn Anywhere</a>
                                    </h3>
                                    <p class="wcu-box_text">Online education often allows learners to study at their
                                        own pace.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 -->

<!-- ----------BC Section----------- -->
<!-- <section class="space">
    <div class="container z-index-common">
        <div class="row d-flex justify-content-center align-item-center">

            <div class="col-auto">
                <div class="title-area mb-30">
                    <span class="sub-title">British Council</span>
                    <h2 class="sec-title fw-medium">
                        Introduction to the British Council (BC)
                    </h2>
                </div>
                <p class="mb-20 ">
                    The British Council is the United Kingdom’s international organization for cultural relations
                    and educational opportunities. It works globally to build trust, mutual understanding, and
                    lasting connections between the UK and partner countries through education, arts, culture,
                    and the English language.
                </p>
                <p class="mb-20 ">
                    In higher education and research, the British Council supports international collaboration,
                    academic mobility, skills development, and institutional capacity building. It plays a key role
                    in strengthening global partnerships that promote inclusion, innovation, and social impact.
                </p>
                <p class="mb-20 ">
                    Through its education and research programs, the British Council actively promotes gender
                    equality, digital transformation, and equitable access to learning opportunities, ensuring that
                    underrepresented groups can participate fully in global knowledge systems.
                </p>

            </div>
        </div>
    </div>

</section> -->

<!-- ----------GGP Section----------- -->
<section class="space   ">
    <div class="container z-index-common">
        <div class="row d-flex justify-content-center align-item-center">

            <div class="col-auto">
                <div class="title-area mb-30">
                    <span class="sub-title">Global Partnerships</span>
                    <h2 class="sec-title fw-medium">
                        Introduction to the Going Global Partnerships Scheme
                    </h2>
                </div>
                <p class="mb-20 ">
                    TThe Going <strong>Global Partnerships (GGP)</strong> scheme is a flagship initiative of the British Council
                    designed to support sustainable international collaboration in education, research, and skills
                    development.
                </p>
                <p class="mb-20 ">
                    The scheme focuses on building long-term partnerships between higher education institutions
                    and industry across countries, enabling co-creation of innovative solutions to shared global
                    challenges.
                </p>
                <p class="mb-20 ">Key objectives of the Going Global Partnerships scheme include:</p>
                <div class="mb-20 ">
                    <ul>
                        <li>Strengthening transnational education and industry-academia collaboration</li>
                        <li>Promoting inclusive access to education and digital skills</li>
                        <li>Supporting gender equality and social inclusion</li>
                        <li>Enhancing employability and workforce readiness</li>
                        <li>Encouraging innovation and applied research</li>
                    </ul>
                </div>
                <p class="mb-20 ">
                    By providing funding, networking, and capacity-building support, the Going Global
                    Partnerships scheme enables institutions to develop impactful projects aligned with global
                    development priorities and the Sustainable Development Goals.
                </p>
            </div>
        </div>
    </div>

</section>





<section class="space bg-smoke">
    <div class="container">
        <div class="title-area text-center">
            <span class="sub-title">Latest News & updates</span>
            <h2 class="sec-title fw-medium">Get Every Single Updates</h2>
        </div>
        <div class="row slider-shadow th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2"
            data-sm-slide-show="1">
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_1.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 15, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Marketing</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Designing Better Link Web Site and Emailsite Valued</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_2.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 16, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Technology</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Morishing Better Link Web Site and Emailsite galowo</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_3.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 17, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Programing</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Kariabnim Better Link Web Site and Emailsite Tanial</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="blog-card">
                    <div class="blog-img">
                        <img src="assets/img/blog/blog_2_4.jpg" alt="blog image" />
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="blog.html"><i class="far fa-clock"></i>March 18, 2023</a>
                            <a href="blog.html"><i class="far fa-folder"></i>Technology</a>
                        </div>
                        <h3 class="blog-title">
                            <a href="updates.php">Gusakanis Better Link Web Site and Emailsite Monasi</a>
                        </h3>
                        <a href="updates.php" class="link-btn">Read Details<i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="shape-mockup d-none d-md-block" data-top="0%" data-left="0%">
        <img src="assets/img/shape/shadow_1.png" alt="shapes" />
    </div>
</section>






<?php include 'includes/footer.php'; ?>